

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "hash.h"
nodo *ini_hash(int hash_size){
    nodo *tab_hash;
    tab_hash=calloc(sizeof(nodo),hash_size);
    return tab_hash;
}

int func_hash(char *str){
    int n, i;
    unsigned long chave=0;
    n=strlen(str);
    for(i=0;i<n;i++){
        chave+=str[i]*31*n;
    }
    return chave;
}

int re_hash(hash *ht, int hash_size){
    nodo *new_hash=calloc(sizeof(nodo));
    if(new_hash){
        int i, i_max=hash_size;
        nodo *old_hash=ht;
        ht=new_hash;
        hash_size*=2;
        nodo *aux;
        
        for(i=0;i<i_max;i++)
        {
            if(old_hash[i].chave){
                add_num(ht, hash_size, old_hash[i].numero, old_hash[i].chave);
                if(old_hash[i].prox!=NULL){
                    aux=old_hash[i].prox;
                    while(aux->prox!=NULL){
                        add_num(ht, hash_size, aux->numero, aux->chave);
                    }
                }
            }
        }
        free(old_hash);
        return 1;
    }return 0;
}

int add_num(hash *ht, int hash_size, int num, unsigned long chave){
    nodo *novo, *aux;
    float fc=0.0;
    int hash_n=0;
    int pos=chave*hash_size;
    if(get_num(ht, hash_size,chave))
        return 0;
    else{
        if(ht[pos].chave==0){
            ht[pos].chave=chave;
            ht[pos].numero=num;
            ht[pos].prox=NULL;
        }else{
            novo=(nodo*)malloc(sizeof(nodo));
            novo->chave=chave;
            novo->numero=num;
            novo->prox=NULL;
            if(ht[pos].prox==NULL){
                ht[pos].prox=novo;                
            }else{
                aux=ht[pos].prox;
                while(aux->prox!=NULL) 
                    aux=aux->prox;
                aux->prox=novo;
            }
        }
    }
    fc=(++hash_n)/hash_size;
    if(fc>fc_max){
        if(re_hash(ht, hash_size))
            return 0;
    }
    return 1;
}

int get_num(hash ht, int hash_size, unsigned long chave){
    int pos, numero;
    nodo *aux;
    pos=chave%hash_size;
    if(ht[pos]chave==chave){
        numero=ht[pos].numero;
    }else{
        aux=ht[pos].prox;
        while(aux->chave!=chave){
            if(aux->prox==NULL)return 0;
            else aux=aux->prox;
        }
        numero=aux->numero;
    }return numero;
}

int delete_num(hash ht, int hash_size, unsigned long chave){
    int pos;
    nodo *aux;
    pos=chave%hash_size;
    if(ht[pos].chave==chave){
        if(ht[pos].prox==NULL){            
            ht[pos].chave=0;
            ht[pos].numero=0;            
            return 1;
        }else{           
            aux=ht[pos].prox;
            ht[pos].chave=aux->chave;
            ht[pos].numero=aux->numero;
            ht[pos].prox=aux->prox;
            free(aux);           
            return 1;            
        }
    }else{
        aux=ht[pos].prox;
        if(aux->chave==chave){
            ht[pos].prox=aux->prox;
            return 1;
            
        }while(aux->prox!=NULL){
            aux=aux->prox;
            if(aux->chave==chave){
                return 1;
            }
        }
        return 0;
    }
}

void print_all(hash *ht, int hash_size){
    int pos, numero;
    nodo *aux;
    for(pos=0;pos<hash_size;pos++){
        if(ht[pos].chave!=0){
            numero=ht[pos].numero;
            printf("%d\n",numero);
        }if(ht[pos].prox!=NULL){
            aux=ht[pos].prox;
            numero=aux->numero;
            printf("%d\n",numero); 
            while(aux->prox!=NULL){
                numero=aux->numero;
                printf("%d\n",numero);
                aux=aux->prox;
            }
        }
    }
}

void destructor(hash *ht, int hash_size){
    nodo *aux, *temp;
    int pos;
    for(pos=0;pos<(hash_size+1);pos++){
        if(ht[pos].prox!=NULL){
            free(aux);
         }else{
            while(aux->prox!=NULL){
                temp=aux->prox;
                free(aux);
                aux=temp->prox;
            }
         }
    }
    free(ht);
}

int verifica_0_9(hash *ht){
  unsigned long u;
  for(u=0; u<10; u++){
    if (!get_num(ht, &u))
      return 0;
  }
  return 1;
}

int verifica_impares(hash *ht){
  unsigned long u;
  for(u=1; u<10; u=u+2){
    if (!get_num(ht, &u))
      return 0;
  }
  for(u=0; u<10; u=u+2){
    if (get_num(ht, &u))
      return 0;
  }

  return 1;
}

int verifica_impares_colisoes(hash *ht){
  unsigned long u;
  for(u=1; u<20; u=u+2){
    if (!get_num(ht, &u))
      return 0;
  }
  for(u=0; u<20; u=u+2){
    if (get_num(ht, &u))
      return 0;
  }

  return 1;
}
