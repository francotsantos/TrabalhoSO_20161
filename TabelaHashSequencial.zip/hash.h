

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#ifndef HASH_H_INCLUDED
#define HASH_H_INCLUDED

#define fc_max 0.7 //fator maximo de colisao

typedef struct nodo{
    unsigned long chave;
    int numero;
    struct nodo prox;
}nodo;

typedef nodo *hash;

int ini_hash(int hash_size); //Funcao de inicializacao
int func_hash(char *str); //Funcao que devolve uma chave 
int re_hash(hash *ht, int hash_size, int hash_n);//Se o fator de colisao chegar a 0.7, fazer o re-hash
int add_num(hash *ht, int hash_size, int num, unsigned long chave);//Funcao de insercao
int get_num(hash *ht, int hash_size, unsigned long chave); //Funcao de busca
int delete_num(hash *ht, int hash_size, unsigned long chave);//Funcao de remocao
int verifica_0_9(hash *ht);//Testa os 10 primeiros elementos da tabela
int verifica_impares(hash *ht);//Testa impares
int verifica_impares_colisoes(hash *ht);//Testa impares e colisoes
void print_all(hash *ht, int hash_size);
void destructor(hash *ht, int hash_size);
#endif