
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "hash.h"

int main(int argc, char ** argv){
  int i, hash_size=10;
  hash *ht = ini_hash(0);
  assert(ht==NULL);

  ht=ini_hash(hash_size);
  assert(ht);
  //Insere 10 elementos sem colisao
  for(i=0; i<10; i++){
    unsigned long *conteudo = (unsigned long*) calloc(1, sizeof(unsigned long));
    assert(conteudo);
    *conteudo = i;
    add_num(ht, hash_size, i, conteudo);
  }
  printf("Teste ate 10 %s\n", verifica_0_9(ht)?"OK":"ERRO");
  printf("Lista \n");
  // /* imprime */
  print_all(ht, hash_size);
 
  /* remove os pares */
 
  for(i=0; i<10; i+=2){
    unsigned long *cont = (unsigned long*) calloc(1, sizeof(unsigned long));
    assert(cont);
    *cont = i;
    unsigned long *elem =get_num(ht, hash_size, cont);
    assert(elem);
    delete_num(ht, hash_size,elem);
    free(elem);
  }
  printf("Teste impares %s\n", verifica_impares(ht)?"OK":"ERRO");
  // /* imprime */
  print_all(ht, hash_size);

  /* colisoes nos impares */
  for(i=1; i<10; i+=2){
    unsigned long * cont = (unsigned long *) malloc(sizeof(unsigned long));
    assert(cont);
    *cont = i;
    add_num(ht, hash_size, i, cont);
    *cont = *cont + 10;
    add_num(ht, hash_size, i, cont);
  }
 
  printf("Teste impares e colisoes %s\n", verifica_impares_colisoes(ht)?"OK":"ERRO");
  /*imprimir lista final*/
  print_all(ht, hash_size);
  
  /*Apagar a tabela*/
  destructor(*ht, hash_size);
  return 0;
}

